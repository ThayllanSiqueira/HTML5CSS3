## Iconic is an open source icon set in raster, vector and font formats

### This version of Iconic is no longer being actively developed. Check out [Open Iconic](https://github.com/iconic/open-iconic) for the latest and greatest.



