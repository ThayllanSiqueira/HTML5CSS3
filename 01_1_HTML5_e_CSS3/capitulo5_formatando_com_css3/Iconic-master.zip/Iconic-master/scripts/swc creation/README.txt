The Iconic class's package is com.somerandomdude.iconic - to import the class, use the code below:

import com.somerandomdude.iconic.Iconic

All icons are embedded SVGs, so they will be treated as SpriteAsset objects. To add a icon (such as the check icon) to an object's display list, use the code below:

addChild(new Iconic.check() as SpriteAsset)

The SWC has been tested in FlexBuilder 3.